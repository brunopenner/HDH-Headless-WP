# WPGraphQL Blocks ACF

## Prerequisites

The [WPGraphQL Blocks](https://github.com/webdeveducation/wp-graphql-blocks) plugin must be installed for this plugin to work.

## Description

This plugin will ensure the correct data is returned for ACF block data when querying for ACF blocks using the _**WPGraphQL Blocks**_ plugin.
